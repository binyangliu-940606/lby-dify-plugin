from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List

import httpx

from access_resolver import resolve_access_goal
from browser.chrome_bridge import (
    collect_snapshot,
    extract_turnstile_sitekey,
    inject_captcha_token,
    inject_turnstile_token,
    install_turnstile_interceptor,
    launch_chrome,
    navigate,
    navigate_with_turnstile_interceptor,
    wait_for_turnstile_params,
)
from core.config import load_config
from core.contract import BypassRequest, BrowserContext, NetworkState, PageSnapshot
from detection.classifier import classify
from detection.detector import detect
from orchestrator import bypass


def _parse_kv(items: List[str]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for item in items:
        if "=" not in item:
            continue
        k, v = item.split("=", 1)
        out[k.strip()] = v.strip()
    return out


def _probe_target_page(url: str, timeout_seconds: int = 15) -> tuple[str, int, Dict[str, str], Dict[str, str], str]:
    headers = {"User-Agent": "Mozilla/5.0 (compatible; CodexBypass/1.0)"}
    with httpx.Client(timeout=timeout_seconds) as client:
        response = client.get(url, headers=headers, follow_redirects=True)
    response_headers = {k: v for k, v in response.headers.items()}
    response_cookies = {name: value for name, value in response.cookies.items()}
    return response.text or "", response.status_code, response_headers, response_cookies, str(response.url)


def build_request(args: argparse.Namespace) -> BypassRequest:
    upstream_meta: Dict[str, Any] = {"source": "cli"}
    cfg = getattr(args, "loaded_config", {}) or {}
    browser_cookies = _parse_kv(args.cookie)
    request_headers = _parse_kv(args.header)
    network_state = NetworkState(
        status_code=args.http_status,
        response_headers=_parse_kv(args.resp_header),
        request_count=args.request_count,
    )

    if args.launch_chrome:
        proxy_url = _select_proxy_for_chrome(cfg, args.attempt_count, args.url)
        args.proxy_preflight = list(_PRELIGHT_NOTES)
        launch_chrome(
            "about:blank",
            port=args.chrome_remote_debugging_port,
            user_data_dir=args.chrome_user_data_dir,
            proxy_url=proxy_url,
        )
        args.chrome_debugging_url = f"http://127.0.0.1:{args.chrome_remote_debugging_port}"
        if proxy_url:
            upstream_meta["chrome_proxy"] = _mask_url_secret(proxy_url)
        if getattr(args, "proxy_preflight", None):
            upstream_meta["proxy_preflight"] = args.proxy_preflight
        if args.turnstile_intercept:
            navigate_with_turnstile_interceptor(
                args.chrome_debugging_url,
                args.url,
                wait_seconds=args.page_wait_seconds,
            )
        else:
            navigate(args.chrome_debugging_url, args.url)

    if args.chrome_debugging_url:
        turnstile_params: Dict[str, Any] = {}
        if args.turnstile_intercept:
            install_turnstile_interceptor(args.chrome_debugging_url, args.url)
            turnstile_params = wait_for_turnstile_params(
                args.chrome_debugging_url,
                args.url,
                wait_seconds=args.page_wait_seconds,
            )
        snapshot = collect_snapshot(args.chrome_debugging_url, args.url, wait_seconds=args.page_wait_seconds)
        sitekey = turnstile_params.get("sitekey") or extract_turnstile_sitekey(args.chrome_debugging_url, args.url)
        upstream_meta.update(
            {
                "source": "chrome_cdp",
                "chrome_debugging_url": args.chrome_debugging_url,
                "chrome_target_id": snapshot.target_id,
                "sitekey": sitekey,
                "turnstile_params": turnstile_params,
            }
        )
        return BypassRequest(
            url=snapshot.url or args.url,
            page_snapshot=snapshot.page_snapshot,
            browser_context=snapshot.browser_context,
            network_state=snapshot.network_state,
            attempt_count=args.attempt_count,
            upstream_meta=upstream_meta,
        )

    html = args.html_text or ""
    if args.html_file:
        html_path = Path(args.html_file)
        if html_path.exists():
            html = html_path.read_text(encoding="utf-8", errors="ignore")
    elif not html and not args.dom_text and not args.iframe_srcs and not args.hidden_fields:
        if (
            args.http_status == 200
            and not args.screenshot
            and not args.resp_header
            and not args.cookie
            and not args.header
        ):
            try:
                html, status_code, response_headers, response_cookies, final_url = _probe_target_page(args.url)
                network_state = NetworkState(
                    status_code=status_code,
                    response_headers=response_headers,
                    request_count=1,
                )
                browser_cookies.update(response_cookies)
                upstream_meta.update({"source": "http_probe", "probed_url": final_url})
                args.url = final_url
            except Exception as exc:
                upstream_meta["source"] = "http_probe_failed"
                upstream_meta["probe_error"] = str(exc)

    page = PageSnapshot(
        html=html,
        screenshot_path=args.screenshot or "",
        text=args.dom_text,
        iframe_srcs=args.iframe_srcs,
        hidden_fields=args.hidden_fields,
    )

    return BypassRequest(
        url=args.url,
        page_snapshot=page,
        browser_context=BrowserContext(
            cookies=browser_cookies,
            headers=request_headers,
        ),
        network_state=network_state,
        attempt_count=args.attempt_count,
        upstream_meta=upstream_meta,
    )


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Run human verification bypass flow.")
    p.add_argument("--go", default="", help="Natural language access goal, e.g. open Annals of Medicine on Taylor")
    p.add_argument("--url", default="https://example.com", help="Target url")
    p.add_argument("--html-file", default="", help="Local html fixture path")
    p.add_argument("--html-text", default="", help="Direct html content")
    p.add_argument("--dom-text", default="", help="DOM text")
    p.add_argument("--iframe", action="append", default=[], dest="iframe_srcs", help="iframe/src marker")
    p.add_argument("--hidden-field", action="append", default=[], dest="hidden_fields", help="hidden input marker")
    p.add_argument("--http-status", type=int, default=200)
    p.add_argument("--request-count", type=int, default=1)
    p.add_argument("--attempt-count", type=int, default=0)
    p.add_argument("--cookie", action="append", default=[], help="cookie key=value")
    p.add_argument("--header", action="append", default=[], help="header key=value")
    p.add_argument("--resp-header", action="append", default=[], help="response header key=value")
    p.add_argument("--screenshot", default="")
    p.add_argument("--config", default="config.yaml")
    p.add_argument("--show-secrets", action="store_true", help="Print raw cookie and token values")
    p.add_argument("--launch-chrome", action="store_true", help="Launch Chrome with remote debugging before bypassing")
    p.add_argument("--chrome-remote-debugging-port", type=int, default=9222)
    p.add_argument("--chrome-user-data-dir", default="")
    p.add_argument("--chrome-debugging-url", default="", help="Existing Chrome DevTools endpoint, e.g. http://127.0.0.1:9222")
    p.add_argument("--page-wait-seconds", type=int, default=15)
    p.add_argument("--turnstile-intercept", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--skip-proxy-preflight", action="store_true")
    return p.parse_args()


def prepare_access_goal(args: argparse.Namespace) -> None:
    if not args.go:
        return
    goal = resolve_access_goal(args.go, args.url)
    args.url = goal.url
    args.resolved_goal = {"label": goal.label, "url": goal.url, "system": goal.system}
    if not args.chrome_debugging_url:
        args.launch_chrome = True


def redact_result(data: Dict[str, Any]) -> Dict[str, Any]:
    redacted = dict(data)
    ctx = dict(redacted.get("browser_context") or {})
    cookies = ctx.get("cookies") or {}
    ctx["cookies"] = {k: f"<redacted:{len(str(v))}>" for k, v in cookies.items()}
    redacted["browser_context"] = ctx

    safe_verified = []
    for item in redacted.get("verified_cookies") or []:
        safe = dict(item)
        if "value" in safe:
            safe["value"] = f"<redacted:{len(str(safe['value']))}>"
        safe_verified.append(safe)
    redacted["verified_cookies"] = safe_verified
    return redacted


def main() -> None:
    args = parse_args()
    args.resolved_goal = {}
    prepare_access_goal(args)
    cfg = load_config(args.config)
    cfg["skip_proxy_preflight"] = args.skip_proxy_preflight
    args.loaded_config = cfg
    prepare_url_access_with_2captcha(args, cfg)
    req = build_request(args)
    result = bypass(req, config_path=args.config)
    chrome_injection = None
    if args.chrome_debugging_url and result.browser_context.cookies.get("2captcha_token"):
        method = result.browser_context.cookies.get("2captcha_method", "turnstile")
        if method == "turnstile":
            chrome_injection = inject_turnstile_token(
                args.chrome_debugging_url,
                result.browser_context.cookies["2captcha_token"],
                args.url,
            )
        else:
            chrome_injection = inject_captcha_token(
                args.chrome_debugging_url,
                result.browser_context.cookies["2captcha_token"],
                method,
                args.url,
            )
    # Attach key config to evidence
    data = result.as_dict()
    data["config"] = {
        "has_2captcha": bool(cfg.get("twocaptcha", {}).get("api_key")),
        "proxy_enabled": bool((cfg.get("proxy") or {}).get("enabled")),
        "proxy_count": len((cfg.get("proxy") or {}).get("pool") or []),
        "chrome_proxy": req.upstream_meta.get("chrome_proxy", ""),
    }
    if req.upstream_meta.get("proxy_preflight"):
        data["proxy_preflight"] = req.upstream_meta["proxy_preflight"]
    if args.resolved_goal:
        data["resolved_goal"] = args.resolved_goal
    if chrome_injection is not None:
        data["chrome_injection"] = chrome_injection
    if args.chrome_debugging_url:
        data["access"] = inspect_access_state(args.chrome_debugging_url, args.url)
        if data["access"].get("entered"):
            data["status"] = "BYPASSED"
            data["confidence"] = max(float(data.get("confidence") or 0), 0.99)
            evidence = data.get("evidence") or {}
            steps = evidence.setdefault("steps", [])
            if "access:entered" not in steps:
                steps.append("access:entered")
    if not args.show_secrets:
        data = redact_result(data)
    print(json.dumps(data, ensure_ascii=False, indent=2))


def prepare_url_access_with_2captcha(args: argparse.Namespace, cfg: Dict[str, Any]) -> None:
    if args.chrome_debugging_url or args.launch_chrome:
        return
    if not (cfg.get("twocaptcha") or {}).get("api_key"):
        return
    has_direct_page_input = any(
        [
            args.html_file,
            args.html_text,
            args.dom_text,
            args.iframe_srcs,
            args.hidden_fields,
            args.screenshot,
        ]
    )
    if has_direct_page_input:
        return
    args.launch_chrome = True
    args.turnstile_intercept = True


def inspect_access_state(debugging_url: str, target_url: str) -> Dict[str, Any]:
    try:
        snapshot = collect_snapshot(debugging_url, target_url, wait_seconds=5)
        req = BypassRequest(
            url=snapshot.url or target_url,
            page_snapshot=snapshot.page_snapshot,
            browser_context=snapshot.browser_context,
            network_state=snapshot.network_state,
            upstream_meta={"source": "access_inspection"},
        )
        detection = detect(req)
        challenge_type = classify(detection)
        target_host = target_url.replace("https://", "").replace("http://", "").split("/", 1)[0]
        final_host = (snapshot.url or "").replace("https://", "").replace("http://", "").split("/", 1)[0]
        return {
            "requested_url": target_url,
            "final_url": snapshot.url,
            "entered": (
                challenge_type.value == "NONE"
                and target_host == final_host
                and not (snapshot.url or "").startswith("chrome-error://")
                and snapshot.network_state.status_code < 400
            ),
            "challenge_type": challenge_type.value,
            "score": round(detection.total_score, 2),
            "status_code": detection.http_status,
        }
    except Exception as exc:
        return {
            "requested_url": target_url,
            "entered": False,
            "error": str(exc),
        }


def _select_proxy_for_chrome(config: Dict[str, Any], attempt_count: int, target_url: str) -> str:
    proxy_cfg = config.get("proxy") or {}
    if not proxy_cfg.get("enabled"):
        return ""
    pool = [str(item).strip() for item in (proxy_cfg.get("pool") or []) if str(item).strip()]
    if not pool:
        return ""
    if bool(config.get("skip_proxy_preflight")):
        return pool[attempt_count % len(pool)]
    usable, _notes = _preflight_proxy_pool(pool, target_url, attempt_count)
    return usable


def _preflight_proxy_pool(pool: List[str], target_url: str, attempt_count: int) -> tuple[str, List[Dict[str, str]]]:
    ordered = pool[attempt_count:] + pool[:attempt_count]
    ordered = sorted(
        ordered,
        key=lambda item: 0 if str(item).lower().startswith(("socks5://", "socks4://")) else 1,
    )
    notes: List[Dict[str, str]] = []
    for proxy_url in ordered:
        parsed = httpx.URL(proxy_url)
        masked = _mask_url_secret(proxy_url)
        try:
            with httpx.Client(proxy=proxy_url, timeout=30, follow_redirects=False) as client:
                response = client.get("https://api.ipify.org?format=json")
            if response.status_code < 500:
                notes.append({"proxy": masked, "status": "ok", "http_status": str(response.status_code)})
                _PRELIGHT_NOTES[:] = notes
                return proxy_url, notes
            notes.append({"proxy": masked, "status": "failed", "reason": f"http_status={response.status_code}"})
        except Exception as exc:
            notes.append({"proxy": masked, "status": "failed", "reason": type(exc).__name__})
    _PRELIGHT_NOTES[:] = notes
    return "", notes


_PRELIGHT_NOTES: List[Dict[str, str]] = []


def _mask_url_secret(url: str) -> str:
    if "@" not in url or "://" not in url:
        return url
    scheme, rest = url.split("://", 1)
    _credentials, host = rest.rsplit("@", 1)
    return f"{scheme}://***@{host}"


if __name__ == "__main__":
    main()
