from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path
from contextlib import AbstractContextManager


class SessionCache(AbstractContextManager):
    def __init__(self, db_path: str = "logs/session_cache.db"):
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.db_path)
        self.conn.execute(
            """
            CREATE TABLE IF NOT EXISTS sessions(
                url TEXT PRIMARY KEY,
                payload TEXT NOT NULL,
                ts INTEGER NOT NULL
            )
            """
        )
        self.conn.commit()

    def store(self, url: str, payload: dict) -> None:
        self.conn.execute(
            "REPLACE INTO sessions(url,payload,ts) VALUES(?,?,?)",
            (url, json.dumps(payload, ensure_ascii=False), int(time.time())),
        )
        self.conn.commit()

    def load(self, url: str):
        cur = self.conn.execute("SELECT payload, ts FROM sessions WHERE url=?", (url,))
        row = cur.fetchone()
        if not row:
            return None
        return json.loads(row[0])

    def close(self):  # pragma: no cover
        self.conn.close()

    def __exit__(self, exc_type, exc, tb):  # pragma: no cover
        self.close()
        return False
