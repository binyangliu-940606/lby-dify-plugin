from __future__ import annotations

from core.contract import ChallengeType


def select_strategy_chain(challenge_type: ChallengeType, has_2captcha_key: bool) -> list[str]:
    match challenge_type:
        case ChallengeType.RECAPTCHA_V2:
            if has_2captcha_key:
                return [
                    "external_solver_2captcha",
                    "js_auto_execute",
                    "proxy_rotate",
                    "session_rotate",
                ]
            return ["js_auto_execute", "proxy_rotate", "session_rotate"]

        case ChallengeType.RECAPTCHA_V3:
            if has_2captcha_key:
                return [
                    "external_solver_2captcha",
                    "js_auto_execute",
                    "proxy_rotate",
                    "session_rotate",
                ]
            return ["js_auto_execute", "proxy_rotate", "session_rotate"]

        case ChallengeType.HCAPTCHA:
            if has_2captcha_key:
                return ["external_solver_2captcha", "proxy_rotate", "session_rotate"]
            return ["wait_human", "proxy_rotate"]

        case ChallengeType.TURNSTILE:
            if has_2captcha_key:
                return [
                    "external_solver_2captcha",
                    "js_auto_execute",
                    "cookie_injection",
                    "proxy_rotate",
                ]
            return ["js_auto_execute", "cookie_injection", "proxy_rotate"]

        case ChallengeType.ARKOSE:
            if has_2captcha_key:
                return ["external_solver_2captcha", "wait_human"]
            return ["wait_human"]

        case ChallengeType.JS_CHALLENGE:
            if has_2captcha_key:
                return [
                    "external_solver_2captcha",
                    "js_auto_execute",
                    "cookie_injection",
                    "proxy_rotate",
                    "session_rotate",
                ]
            return ["js_auto_execute", "cookie_injection", "proxy_rotate", "session_rotate"]

        case ChallengeType.RATE_LIMIT:
            if has_2captcha_key:
                return ["external_solver_2captcha", "proxy_rotate", "session_rotate"]
            return ["proxy_rotate", "session_rotate"]

        case ChallengeType.CUSTOM:
            if has_2captcha_key:
                return ["external_solver_2captcha", "cookie_injection", "proxy_rotate", "session_rotate", "escalate"]
            return ["cookie_injection", "proxy_rotate", "session_rotate", "escalate"]

        case ChallengeType.UNKNOWN:
            if has_2captcha_key:
                return ["external_solver_2captcha", "cookie_injection", "proxy_rotate", "session_rotate", "escalate"]
            return ["cookie_injection", "proxy_rotate", "session_rotate", "escalate"]

        case _:
            return ["session_rotate", "escalate"]
