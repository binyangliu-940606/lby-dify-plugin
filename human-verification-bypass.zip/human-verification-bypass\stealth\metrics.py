from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict


@dataclass
class MetricsSink:
    counters: Dict[str, int] = field(default_factory=dict)
    last_status: Dict[str, str] = field(default_factory=dict)

    def inc(self, key: str, amount: int = 1) -> None:
        self.counters[key] = self.counters.get(key, 0) + amount

    def record_status(self, domain: str, status: str) -> None:
        self.last_status[domain] = status
