import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from core.contract import BypassRequest, PageSnapshot
from detection.detector import detect


def test_detector_smoke():
    req = BypassRequest(
        url="https://example.com/captcha",
        page_snapshot=PageSnapshot(
            html="<html><body>please verify you are human</body></html>",
            iframe_srcs=["https://challenges.cloudflare.com/cdn-cgi/challenge-platform"],
            hidden_fields=[],
        ),
    )
    det = detect(req)
    assert det.total_score >= 0.0
