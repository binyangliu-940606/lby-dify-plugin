from __future__ import annotations

import os
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict

try:
    import yaml
except Exception:  # pragma: no cover
    yaml = None


DEFAULT_CONFIG: Dict[str, Any] = {
    "twocaptcha": {
        "api_key": "",
        "timeout": 120,
        "polling_interval": 5,
        "max_retries": 2,
        "service": "2captcha.com",
    },
    "proxy": {
        "enabled": False,
        "pool": [],
        "provider": "",
        "rotate_on_block": True,
    },
    "detection": {
        "scoring": {
            "threshold": 0.55,
            "bypass_recheck": 0.30,
            "dimensions": {
                "url_pattern": {"weight": 0.25},
                "dom_keywords": {"weight": 0.30},
                "iframe_src": {"weight": 0.35},
                "http_status": {"weight": 0.20},
                "resource_block": {"weight": 0.15},
            },
        }
    },
    "stealth": {
        "enabled": True,
        "patches": ["webdriver", "plugins", "languages", "webgl", "canvas", "screen", "timezone"],
    },
    "session_cache": {
        "enabled": True,
        "ttl_minutes": 10,
        "db_path": "logs/session_cache.db",
    },
    "circuit_breaker": {
        "consecutive_failures": 3,
        "failure_window": 600,
        "cooldown": 300,
    },
}


def load_config(config_path: str = "config.yaml") -> Dict[str, Any]:
    conf = deepcopy(DEFAULT_CONFIG)
    path = Path(config_path)
    if not path.is_absolute() and not path.exists():
        path = Path(__file__).resolve().parents[1] / config_path
    if path.exists() and yaml is not None:
        with path.open("r", encoding="utf-8") as f:
            loaded = yaml.safe_load(f) or {}
        if isinstance(loaded, dict):
            conf = _deep_merge(conf, loaded)

    env_key = os.getenv("2CAPTCHA_API_KEY") or os.getenv("TWOCAPTCHA_API_KEY")
    if env_key:
        conf.setdefault("twocaptcha", {})["api_key"] = env_key
    return conf


def _deep_merge(left: Dict[str, Any], right: Dict[str, Any]) -> Dict[str, Any]:
    merged = dict(left)
    for k, v in right.items():
        if isinstance(v, dict) and isinstance(merged.get(k), dict):
            merged[k] = _deep_merge(merged[k], v)
        else:
            merged[k] = v
    return merged
