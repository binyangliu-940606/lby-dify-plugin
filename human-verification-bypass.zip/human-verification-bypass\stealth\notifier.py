from __future__ import annotations

import json
from datetime import datetime, timezone


def notify(level: str, message: str, payload: dict | None = None) -> str:
    event = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "level": level,
        "message": message,
        "payload": payload or {},
    }
    line = json.dumps(event, ensure_ascii=False)
    print(line)
    return line
