from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List


@dataclass(frozen=True)
class AccessGoal:
    label: str
    url: str
    system: str = ""


KNOWN_GOALS: List[AccessGoal] = [
    AccessGoal(
        label="Annals of Medicine",
        url="https://www.tandfonline.com/toc/iann20/current",
        system="Taylor",
    ),
]


def resolve_access_goal(text: str, fallback_url: str = "") -> AccessGoal:
    query = (text or "").strip()
    fallback = (fallback_url or "").strip()

    direct = _extract_url(query)
    if direct:
        return AccessGoal(label=query or direct, url=direct)

    query_lower = query.lower()
    for goal in KNOWN_GOALS:
        label_hit = goal.label.lower() in query_lower
        system_hit = not goal.system or goal.system.lower() in query_lower or _system_alias(goal.system) in query_lower
        if label_hit and system_hit:
            return goal

    if fallback and fallback != "https://example.com":
        return AccessGoal(label=query or fallback, url=fallback)

    raise ValueError(
        "Could not resolve access goal. Provide a URL or add a site alias in access_resolver.py."
    )


def _extract_url(text: str) -> str:
    match = re.search(r"https?://[^\\s]+", text)
    if match:
        return match.group(0)

    domain_match = re.search(r"\\b(?:www\\.)?[a-z0-9.-]+\\.[a-z]{2,}(?:/[^\\s]*)?", text, flags=re.I)
    if domain_match:
        value = domain_match.group(0)
        if not value.startswith(("http://", "https://")):
            value = f"https://{value}"
        return value
    return ""


def _system_alias(system: str) -> str:
    aliases = {
        "Taylor": "taylor",
    }
    return aliases.get(system, system).lower()
