from __future__ import annotations

from typing import List

import re


def score_url(url_lower: str) -> float:
    if not url_lower:
        return 0.0
    kws = ("captcha", "challenge", "verify", "security-check", "human", "cf_chl")
    return 0.35 if any(k in url_lower for k in kws) else 0.0


def score_dom(dom_text: str) -> float:
    text = (dom_text or "").lower()
    kws = (
        "i am not a robot",
        "verify you are human",
        "security check",
        "checking your browser",
        "enable javascript",
        "please verify",
        "cloudflare",
        "just a moment",
        "请稍候",
        "请验证您是真人",
        "进行安全验证",
        "access denied",
        "unusual activity",
    )
    return 0.35 if any(k in text for k in kws) else 0.0


def score_iframe(srcs: list[str], hidden_fields: list[str]) -> float:
    src_blob = " ".join(srcs + hidden_fields).lower()
    kws = (
        "google.com/recaptcha",
        "g-recaptcha-response",
        "hcaptcha.com",
        "h-captcha-response",
        "challenges.cloudflare.com",
        "cf-turnstile-response",
        "arkoselabs",
        "funcaptcha",
        "cf-browser-verification",
        "window._cf_chl_opt",
    )
    return 0.35 if any(k in src_blob for k in kws) else 0.0


def score_http(status_code: int, request_count: int) -> float:
    score = 0.35 if status_code == 599 else (0.20 if status_code in (403, 429, 451) else 0.0)
    if request_count > 20:
        score += 0.05
    return min(score, 0.25)


def score_resource_blocked(resource_blocked: bool) -> float:
    return 0.15 if resource_blocked else 0.0


def normalize_tokens(text: str) -> List[str]:
    return [t for t in re.split(r"[^a-z0-9_./-]+", text.lower()) if t]


def build_scores(url_lower: str, dom_text: str, srcs: list[str], hidden_fields: list[str], http_status: int, request_count: int, blocked: bool) -> dict[str, float]:
    return {
        "url_pattern": score_url(url_lower),
        "dom_keywords": score_dom(dom_text),
        "iframe_src": score_iframe(srcs, hidden_fields),
        "http_status": score_http(http_status, request_count),
        "resource_block": score_resource_blocked(blocked),
        "normalized_tokens": normalize_tokens(f"{url_lower} {dom_text}"),
    }
