from __future__ import annotations

from core.contract import ChallengeType, DetectionResult


def _has_text(haystack: str, *needles: str) -> bool:
    return any(needle in haystack for needle in needles)


def classify(detection: DetectionResult) -> ChallengeType:
    srcs = " ".join(detection.iframe_srcs).lower()
    fields = " ".join(detection.hidden_fields).lower()
    dom = detection.dom_text.lower()
    url = detection.url_lower
    text = f"{url} {dom} {srcs} {fields}"

    if "google.com/recaptcha" in srcs:
        if "g-recaptcha-response" in fields:
            return ChallengeType.RECAPTCHA_V2
        return ChallengeType.RECAPTCHA_V3

    if "challenges.cloudflare.com" in srcs or "cf-turnstile-response" in fields:
        return ChallengeType.TURNSTILE

    if "hcaptcha" in srcs:
        return ChallengeType.HCAPTCHA

    if "arkoselabs" in srcs or "funcaptcha" in srcs:
        return ChallengeType.ARKOSE

    if "cf-browser-verification" in srcs or "cf_browser_verification" in fields:
        return ChallengeType.JS_CHALLENGE

    if _has_text(
        dom,
        "checking your browser",
        "_cf_chl_opt",
        "just a moment",
        "please wait while your browser is being verified",
        "cloudflare",
    ):
        return ChallengeType.JS_CHALLENGE

    if detection.resource_blocked:
        # Treat anti-bot blocks as verification/rate-limit paths, not a normal success page.
        return ChallengeType.RATE_LIMIT

    if detection.http_status in (429, 451, 599):
        return ChallengeType.RATE_LIMIT

    if detection.http_status == 403:
        return ChallengeType.CUSTOM

    if _has_text(dom, "i am not a robot", "verify you are human", "verify your identity", "access denied", "unusual activity"):
        return ChallengeType.CUSTOM

    if detection.total_score >= 0.55:
        return ChallengeType.CUSTOM

    return ChallengeType.NONE
