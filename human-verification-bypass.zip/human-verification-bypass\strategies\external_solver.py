from __future__ import annotations

import re
import time
import urllib.parse
from typing import Any, Dict, Tuple

import httpx

from core.contract import BypassRequest, ChallengeType
from strategies.base import Strategy


class ExternalSolver2CaptchaStrategy(Strategy):
    strategy_id = "external_solver_2captcha"

    @staticmethod
    def execute(request: BypassRequest, config: Dict[str, Any], _challenge_type: ChallengeType) -> Tuple[bool, str]:
        twocaptcha_cfg = config.get("twocaptcha") or {}
        key = twocaptcha_cfg.get("api_key", "").strip()
        if not key:
            return False, "2captcha api key missing"

        task, method, note = _build_2captcha_task(request, config, _challenge_type)
        if not task:
            return False, note

        token, solution, note = _solve_task_v2(key, task, twocaptcha_cfg)
        if not token:
            return False, note

        request.browser_context.cookies["2captcha_token"] = token
        request.browser_context.cookies["2captcha_method"] = method
        if solution.get("userAgent"):
            request.browser_context.headers["User-Agent"] = str(solution["userAgent"])
            request.browser_context.cookies["2captcha_user_agent"] = str(solution["userAgent"])
        return True, f"{note}; method={method}"


def _build_2captcha_task(
    request: BypassRequest,
    config: Dict[str, Any],
    challenge_type: ChallengeType,
) -> Tuple[Dict[str, Any], str, str]:
    meta = request.upstream_meta or {}
    page_url = _canonical_page_url(meta, request.url)
    proxy = _select_proxy(config, request.attempt_count)

    if challenge_type in (
        ChallengeType.TURNSTILE,
        ChallengeType.JS_CHALLENGE,
        ChallengeType.RATE_LIMIT,
        ChallengeType.CUSTOM,
        ChallengeType.UNKNOWN,
    ):
        params = meta.get("turnstile_params") or {}
        sitekey = (
            params.get("sitekey")
            or _extract_sitekey_from_text(str(params.get("pageUrl") or ""))
            or meta.get("sitekey")
            or _extract_turnstile_sitekey(request)
        )
        if sitekey:
            task = {
                "type": "TurnstileTask" if proxy else "TurnstileTaskProxyless",
                "websiteURL": params.get("pageUrl") or page_url,
                "websiteKey": sitekey,
            }
            for key in ("action", "data", "pagedata", "userAgent"):
                if params.get(key):
                    task[key] = params[key]
            _attach_proxy(task, proxy)
            challenge_note = "turnstile challenge params captured" if any(task.get(k) for k in ("action", "data", "pagedata")) else "turnstile standalone params captured"
            return task, "turnstile", challenge_note

    if challenge_type in (ChallengeType.RECAPTCHA_V2, ChallengeType.RATE_LIMIT, ChallengeType.CUSTOM, ChallengeType.UNKNOWN):
        sitekey = meta.get("sitekey") or _extract_recaptcha_sitekey(request)
        if sitekey:
            task = {
                "type": "RecaptchaV2Task" if proxy else "RecaptchaV2TaskProxyless",
                "websiteURL": page_url,
                "websiteKey": sitekey,
                "isInvisible": _looks_invisible(request),
            }
            _attach_user_context(task, request)
            _attach_proxy(task, proxy)
            return task, "recaptcha_v2", "recaptcha v2 params captured"

    if challenge_type == ChallengeType.RECAPTCHA_V3:
        sitekey = meta.get("sitekey") or _extract_recaptcha_sitekey(request)
        if sitekey:
            task = {
                "type": "RecaptchaV3TaskProxyless",
                "websiteURL": page_url,
                "websiteKey": sitekey,
                "minScore": float(meta.get("min_score") or 0.3),
                "pageAction": str(meta.get("action") or "verify"),
            }
            return task, "recaptcha_v3", "recaptcha v3 params captured"

    if challenge_type in (ChallengeType.HCAPTCHA, ChallengeType.RATE_LIMIT, ChallengeType.CUSTOM, ChallengeType.UNKNOWN):
        sitekey = meta.get("sitekey") or _extract_hcaptcha_sitekey(request)
        if sitekey:
            task = {
                "type": "HCaptchaTask" if proxy else "HCaptchaTaskProxyless",
                "websiteURL": page_url,
                "websiteKey": sitekey,
            }
            _attach_user_context(task, request)
            _attach_proxy(task, proxy)
            return task, "hcaptcha", "hcaptcha params captured"

    if challenge_type in (ChallengeType.ARKOSE, ChallengeType.RATE_LIMIT, ChallengeType.CUSTOM, ChallengeType.UNKNOWN):
        public_key = meta.get("public_key") or _extract_arkose_public_key(request)
        if public_key:
            task = {
                "type": "FunCaptchaTask" if proxy else "FunCaptchaTaskProxyless",
                "websiteURL": page_url,
                "websitePublicKey": public_key,
            }
            _attach_proxy(task, proxy)
            return task, "funcaptcha", "arkose funcaptcha params captured"

    return {}, "", f"2captcha supported challenge parameters not found for {challenge_type.value}"


def _solve_task_v2(api_key: str, task: Dict[str, Any], cfg: Dict[str, Any]) -> Tuple[str, Dict[str, Any], str]:
    timeout = int(cfg.get("timeout") or 120)
    interval = max(1, int(cfg.get("polling_interval") or 5))
    endpoint = _api_base(cfg)
    create_payload = {"clientKey": api_key, "task": task}

    try:
        with httpx.Client(timeout=max(30, interval + 10)) as client:
            created = client.post(f"{endpoint}/createTask", json=create_payload)
            created.raise_for_status()
            create_data = created.json()
            if create_data.get("errorId"):
                return "", {}, f"2captcha createTask failed: {create_data.get('errorCode') or create_data.get('errorDescription')}"
            task_id = create_data.get("taskId")
            if not task_id:
                return "", {}, "2captcha createTask returned no taskId"

            deadline = time.time() + timeout
            while time.time() < deadline:
                time.sleep(interval)
                result = client.post(
                    f"{endpoint}/getTaskResult",
                    json={"clientKey": api_key, "taskId": task_id},
                )
                result.raise_for_status()
                data = result.json()
                if data.get("errorId"):
                    return "", {}, f"2captcha getTaskResult failed: {data.get('errorCode') or data.get('errorDescription')}"
                if data.get("status") != "ready":
                    continue
                solution = data.get("solution") or {}
                token = str(solution.get("token") or solution.get("gRecaptchaResponse") or solution.get("code") or "")
                if token:
                    return token, solution, "2captcha token obtained"
                return "", solution, "2captcha returned ready result without token"
    except Exception as exc:
        return "", {}, f"2captcha api failed: {type(exc).__name__}: {exc}"

    return "", {}, "2captcha solving timed out"


def _api_base(cfg: Dict[str, Any]) -> str:
    service = str(cfg.get("service") or "2captcha.com").strip().rstrip("/")
    if service.startswith("http://") or service.startswith("https://"):
        return service
    return "https://api.2captcha.com"


def _canonical_page_url(meta: Dict[str, Any], fallback: str) -> str:
    params = meta.get("turnstile_params") or {}
    return str(params.get("pageUrl") or meta.get("probed_url") or fallback)


def _select_proxy(config: Dict[str, Any], attempt_count: int) -> str:
    proxy_cfg = config.get("proxy") or {}
    if not proxy_cfg.get("enabled"):
        return ""
    pool = [str(item).strip() for item in (proxy_cfg.get("pool") or []) if str(item).strip()]
    if not pool:
        return ""
    return pool[attempt_count % len(pool)]


def _attach_proxy(task: Dict[str, Any], proxy_url: str) -> None:
    if not proxy_url:
        return
    parsed = urllib.parse.urlparse(proxy_url)
    if not parsed.scheme or not parsed.hostname:
        return
    task["proxyType"] = "socks5" if parsed.scheme.lower().startswith("socks5") else "http"
    task["proxyAddress"] = parsed.hostname
    task["proxyPort"] = int(parsed.port or (443 if parsed.scheme == "https" else 80))
    if parsed.username:
        task["proxyLogin"] = urllib.parse.unquote(parsed.username)
    if parsed.password:
        task["proxyPassword"] = urllib.parse.unquote(parsed.password)


def _attach_user_context(task: Dict[str, Any], request: BypassRequest) -> None:
    ua = request.browser_context.headers.get("User-Agent") or request.upstream_meta.get("userAgent")
    if ua:
        task["userAgent"] = str(ua)
    if request.browser_context.cookies:
        task["cookies"] = "; ".join(f"{k}={v}" for k, v in request.browser_context.cookies.items())


def _page_blob(request: BypassRequest) -> str:
    page = request.page_snapshot
    return "\n".join(
        [
            request.url,
            page.html or "",
            page.text or "",
            " ".join(page.iframe_srcs or []),
            " ".join(page.hidden_fields or []),
        ]
    )


def _extract_turnstile_sitekey(request: BypassRequest) -> str:
    blob = _page_blob(request)
    patterns = [
        r'data-sitekey=["\']([^"\']+)["\']',
        r'sitekey["\']?\s*[:=]\s*["\']([^"\']+)["\']',
        r'/turnstile/v0/[^"\']*?k=([^&"\']+)',
        r'challenges\.cloudflare\.com/[^"\']*/(0x[A-Za-z0-9_-]{10,})',
    ]
    return _first_match(blob, patterns)


def _extract_recaptcha_sitekey(request: BypassRequest) -> str:
    blob = _page_blob(request)
    patterns = [
        r'g-recaptcha[^>]+data-sitekey=["\']([^"\']+)["\']',
        r'data-sitekey=["\']([^"\']+)["\']',
        r'[?&]k=([^&"\']+)',
        r'grecaptcha\.execute\(["\']([^"\']+)["\']',
        r'sitekey["\']?\s*[:=]\s*["\']([^"\']+)["\']',
    ]
    return _first_match(blob, patterns)


def _extract_hcaptcha_sitekey(request: BypassRequest) -> str:
    blob = _page_blob(request)
    patterns = [
        r'h-captcha[^>]+data-sitekey=["\']([^"\']+)["\']',
        r'hcaptcha[^"\']*sitekey["\']?\s*[:=]\s*["\']([^"\']+)["\']',
        r'data-sitekey=["\']([^"\']+)["\']',
    ]
    return _first_match(blob, patterns)


def _extract_arkose_public_key(request: BypassRequest) -> str:
    blob = _page_blob(request)
    patterns = [
        r'public_key["\']?\s*[:=]\s*["\']([^"\']+)["\']',
        r'websitePublicKey["\']?\s*[:=]\s*["\']([^"\']+)["\']',
        r'funcaptcha[^"\']*pk=([^&"\']+)',
    ]
    return _first_match(blob, patterns)


def _first_match(blob: str, patterns: list[str]) -> str:
    for pattern in patterns:
        match = re.search(pattern, blob, flags=re.IGNORECASE)
        if match:
            return urllib.parse.unquote(match.group(1))
    return ""


def _extract_sitekey_from_text(value: str) -> str:
    return _first_match(value, [r"/(0x[A-Za-z0-9_-]{10,})(?:/|$|\?)"])


def _looks_invisible(request: BypassRequest) -> bool:
    return "invisible" in _page_blob(request).lower()
