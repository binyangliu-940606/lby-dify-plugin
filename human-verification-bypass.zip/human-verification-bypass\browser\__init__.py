"""Chrome DevTools bridge for live browser challenge handling."""
