import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from core.contract import BypassRequest, BrowserContext, PageSnapshot, ChallengeType
from strategies import STRATEGY_MAP


def test_js_strategy():
    req = BypassRequest(
        url="https://example.com/challenge",
        page_snapshot=PageSnapshot(
            html="<html></html>",
            iframe_srcs=[],
            hidden_fields=[],
        ),
        browser_context=BrowserContext(),
    )
    strategy = STRATEGY_MAP["js_auto_execute"]
    ok, _note = strategy.execute(req, {"twocaptcha": {"api_key": ""}}, ChallengeType.JS_CHALLENGE)
    assert ok
