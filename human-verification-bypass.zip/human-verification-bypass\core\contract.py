from __future__ import annotations

import hashlib
import re
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Sequence


class BypassStatus(str, Enum):
    BYPASSED = "BYPASSED"
    NEED_HUMAN = "NEED_HUMAN"
    ESCALATE = "ESCALATE"
    ABANDON = "ABANDON"


class ChallengeType(str, Enum):
    NONE = "NONE"
    RECAPTCHA_V2 = "recaptcha_v2"
    RECAPTCHA_V3 = "recaptcha_v3"
    HCAPTCHA = "hcaptcha"
    TURNSTILE = "turnstile"
    ARKOSE = "arkose"
    JS_CHALLENGE = "js_challenge"
    RATE_LIMIT = "rate_limit"
    CUSTOM = "custom"
    UNKNOWN = "unknown"


@dataclass
class PageSnapshot:
    html: str = ""
    screenshot_path: str = ""
    text: str = ""
    iframe_srcs: Sequence[str] = ()
    hidden_fields: Sequence[str] = ()

    def normalized_text(self) -> str:
        if self.text:
            base = self.text.lower()
        else:
            base = re.sub(r"<[^>]+>", " ", self.html.lower())
        return re.sub(r"\s+", " ", base).strip()


@dataclass
class BrowserContext:
    cookies: Dict[str, str] = field(default_factory=dict)
    headers: Dict[str, str] = field(default_factory=dict)
    session_id: str = field(default_factory=lambda: uuid.uuid4().hex)

    def fingerprint(self) -> Dict[str, str]:
        return {"session_id": self.session_id}


@dataclass
class NetworkState:
    status_code: int = 200
    response_headers: Dict[str, str] = field(default_factory=dict)
    request_count: int = 1


@dataclass
class BypassRequest:
    url: str
    page_snapshot: PageSnapshot
    browser_context: BrowserContext = field(default_factory=BrowserContext)
    network_state: NetworkState = field(default_factory=NetworkState)
    attempt_count: int = 0
    upstream_meta: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DetectionResult:
    url: str
    url_lower: str
    dom_text: str
    iframe_srcs: Sequence[str]
    hidden_fields: Sequence[str]
    http_status: int
    resource_blocked: bool
    scores: Dict[str, float]
    total_score: float


@dataclass
class Evidence:
    detection: Dict[str, Any]
    steps: List[str]
    screenshot_id: str = ""


@dataclass
class BypassResult:
    status: BypassStatus
    browser_context: BrowserContext
    verified_cookies: List[Dict[str, str]]
    bypass_method: str
    duration_ms: int
    log_id: str
    evidence: Evidence
    confidence: float

    def as_dict(self) -> Dict[str, Any]:
        from dataclasses import asdict

        payload = asdict(self)
        payload["status"] = self.status.value
        return payload


def make_cookie(domain: str, name: str, value: str) -> Dict[str, str]:
    return {
        "name": name,
        "value": value,
        "domain": domain,
        "signature": hashlib.sha1(f"{name}:{value}".encode()).hexdigest()[:10],
    }
