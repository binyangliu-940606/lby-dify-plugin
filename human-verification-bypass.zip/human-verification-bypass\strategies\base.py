from __future__ import annotations

from typing import Any, Dict, Tuple

from core.contract import BypassRequest, ChallengeType


class Strategy:
    strategy_id = "base"

    @staticmethod
    def execute(request: BypassRequest, config: Dict[str, Any], challenge_type: ChallengeType) -> Tuple[bool, str]:
        """
        Return tuple(success, note).
        """
        return False, "not_implemented"
