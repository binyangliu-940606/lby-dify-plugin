from __future__ import annotations

import re
from typing import List

from core.contract import BypassRequest, DetectionResult
from detection.features import build_scores


def normalize_tokens(text: str) -> List[str]:
    return [t for t in re.split(r"[^a-z0-9_./-]+", text.lower()) if t]


def detect(request: BypassRequest) -> DetectionResult:
    url = request.url or ""
    url_lower = url.lower()
    dom_text = request.page_snapshot.normalized_text()
    iframe_srcs = list(request.page_snapshot.iframe_srcs or [])
    hidden_fields = list(request.page_snapshot.hidden_fields or [])
    http_status = request.network_state.status_code
    blocked = http_status in (403, 429, 451)

    scores = build_scores(url_lower, dom_text, iframe_srcs, hidden_fields, http_status, request.network_state.request_count, blocked)
    dimension_scores = {k: v for k, v in scores.items() if k != "normalized_tokens"}
    total = sum(dimension_scores.values())

    return DetectionResult(
        url=url,
        url_lower=url_lower,
        dom_text=dom_text,
        iframe_srcs=iframe_srcs,
        hidden_fields=hidden_fields,
        http_status=http_status,
        resource_blocked=blocked,
        scores=dimension_scores,
        total_score=min(total, 1.0),
    )
