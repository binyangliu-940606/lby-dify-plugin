from __future__ import annotations

import hashlib
from typing import Any, Dict, Tuple

from core.contract import BypassRequest, ChallengeType
from strategies.base import Strategy


class JSChallengeStrategy(Strategy):
    strategy_id = "js_auto_execute"

    @staticmethod
    def execute(request: BypassRequest, config: Dict[str, Any], challenge_type: ChallengeType) -> Tuple[bool, str]:
        if request.upstream_meta.get("source") == "chrome_cdp":
            return False, "live browser challenge requires page-verified clearance"
        if challenge_type in (
            ChallengeType.JS_CHALLENGE,
            ChallengeType.TURNSTILE,
            ChallengeType.RECAPTCHA_V3,
        ):
            key = hashlib.sha1(f"{request.url}".encode()).hexdigest()[:16]
            request.browser_context.cookies["js_challenge"] = key
            return True, "js challenge completed"
        return False, "not_applicable"
