from __future__ import annotations

from copy import deepcopy
from typing import Dict, Tuple

from core.contract import BrowserContext


def merge_cookies(
    base: Dict[str, str], incoming: Dict[str, str]
) -> Dict[str, str]:
    merged = dict(base)
    merged.update(incoming or {})
    return merged


def dump_cookies_to_ctx(ctx: BrowserContext, cookies: Dict[str, str]) -> BrowserContext:
    context = ctx
    context.cookies = merge_cookies(context.cookies, cookies or {})
    return context


def extract_cookie_pairs(cookie_text: str) -> Dict[str, str]:
    pairs: Dict[str, str] = {}
    if not cookie_text:
        return pairs
    for item in cookie_text.split(";"):
        if "=" not in item:
            continue
        k, v = item.split("=", 1)
        pairs[k.strip()] = v.strip()
    return pairs
