from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass
from typing import Any, Dict

from core.config import load_config
from core.contract import (
    BypassRequest,
    BypassResult,
    BypassStatus,
    ChallengeType,
    Evidence,
    make_cookie,
)
from core.strategy_selector import select_strategy_chain
from detection.classifier import classify
from detection.detector import detect
from session.cache import SessionCache
from strategies import STRATEGY_MAP


@dataclass
class OrchestratorConfig:
    threshold: float = 0.55
    bypass_recheck: float = 0.30


def _guess_domain(url: str) -> str:
    no_scheme = url.replace("https://", "").replace("http://", "")
    return no_scheme.split("/", 1)[0] if no_scheme else ""


def _build_evidence_id(log_id: str) -> str:
    return hashlib.sha1(log_id.encode()).hexdigest()[:12]


def _verify_bypass(req: BypassRequest) -> bool:
    return len(req.browser_context.cookies) > 0


def bypass(request: BypassRequest, config_path: str = "config.yaml") -> BypassResult:
    config = load_config(config_path)
    start = time.perf_counter()
    log_id = hashlib.sha1(f"{request.url}:{time.time()}".encode()).hexdigest()[:16]
    steps = []

    detection = detect(request)
    challenge_type = classify(detection)
    steps.append(f"detected:{challenge_type.value}")
    steps.append(f"score:{detection.total_score:.2f}")

    if challenge_type == ChallengeType.NONE:
        return BypassResult(
            status=BypassStatus.BYPASSED,
            browser_context=request.browser_context,
            verified_cookies=[],
            bypass_method="none",
            duration_ms=0,
            log_id=log_id,
            evidence=Evidence(
                detection={
                    "url": request.url,
                    "challenge_type": challenge_type.value,
                    "scores": detection.scores,
                    "status_code": detection.http_status,
                },
                steps=steps,
                screenshot_id=_build_evidence_id(log_id),
            ),
            confidence=0.99,
        )

    chain = select_strategy_chain(challenge_type, bool(config.get("twocaptcha", {}).get("api_key")))
    steps.append(f"chain:{','.join(chain)}")

    success = False
    final_strategy = "none"
    status = BypassStatus.ABANDON

    for strategy in chain:
        steps.append(f"try:{strategy}")
        if strategy == "escalate":
            status = BypassStatus.ESCALATE
            final_strategy = strategy
            break

        strategy_cls = STRATEGY_MAP.get(strategy)
        if not strategy_cls:
            continue
        did_apply, note = strategy_cls.execute(request, config, challenge_type)
        steps.append(f"{strategy}:{note}")
        final_strategy = strategy

        if did_apply and _verify_bypass(request):
            success = True
            status = BypassStatus.BYPASSED
            break

        if strategy == "wait_human":
            status = BypassStatus.NEED_HUMAN
            break

    if not success and status == BypassStatus.ABANDON and request.attempt_count >= 2:
        status = BypassStatus.ESCALATE

    duration_ms = int((time.perf_counter() - start) * 1000)
    domain = _guess_domain(request.url)
    verified = [make_cookie(domain, name, value) for name, value in request.browser_context.cookies.items()]

    return BypassResult(
        status=status,
        browser_context=request.browser_context,
        verified_cookies=verified,
        bypass_method=final_strategy,
        duration_ms=duration_ms,
        log_id=log_id,
        evidence=Evidence(
            detection={
                "url": request.url,
                "challenge_type": challenge_type.value,
                "scores": detection.scores,
                "status_code": detection.http_status,
                "resource_blocked": detection.resource_blocked,
            },
            steps=steps,
            screenshot_id=_build_evidence_id(log_id),
        ),
        confidence=0.85 if success else 0.25,
    )


def build_result_with_cache(request: BypassRequest, config: Dict[str, Any]) -> BypassResult:
    cache_cfg = config.get("session_cache", {})
    result = bypass(request, config_path="config.yaml")
    if cache_cfg.get("enabled", True):
        with SessionCache(cache_cfg.get("db_path", "logs/session_cache.db")) as cache:
            cache.store(request.url, result.as_dict())
    return result
