from __future__ import annotations

import uuid
from typing import Any, Dict, Tuple

from core.contract import BypassRequest
from strategies.base import Strategy


class SessionRotateStrategy(Strategy):
    strategy_id = "session_rotate"

    @staticmethod
    def execute(request: BypassRequest, config: Dict[str, Any], _challenge_type) -> Tuple[bool, str]:
        request.browser_context.session_id = uuid.uuid4().hex
        request.browser_context.headers["x-session-id"] = request.browser_context.session_id
        return False, "session rotated"
