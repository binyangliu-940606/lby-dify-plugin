from __future__ import annotations

from typing import Any, Dict, Tuple

from core.contract import BypassRequest
from strategies.base import Strategy


class WaitHumanStrategy(Strategy):
    strategy_id = "wait_human"

    @staticmethod
    def execute(request: BypassRequest, config: Dict[str, Any], _challenge_type) -> Tuple[bool, str]:
        return False, "manual human intervention required"
