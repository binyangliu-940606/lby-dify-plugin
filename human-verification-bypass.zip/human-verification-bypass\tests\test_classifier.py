import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from core.contract import BypassRequest, DetectionResult, PageSnapshot
from detection.classifier import classify


def test_classify_custom():
    detection = DetectionResult(
        url="https://example.com/captcha",
        url_lower="https://example.com/captcha",
        dom_text="please verify you are human",
        iframe_srcs=["https://challenges.cloudflare.com/cdn-cgi/challenge-platform"],
        hidden_fields=[],
        http_status=403,
        resource_blocked=True,
        scores={},
        total_score=0.8,
    )
    assert classify(detection).value in {"turnstile", "rate_limit", "js_challenge", "custom"}
