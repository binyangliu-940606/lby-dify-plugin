"""
Minimal tests for local smoke checks (optional).
"""
