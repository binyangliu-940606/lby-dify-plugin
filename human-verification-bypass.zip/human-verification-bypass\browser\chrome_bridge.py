from __future__ import annotations

import base64
import hashlib
import json
import os
import select
import shutil
import socket
import socketserver
import struct
import subprocess
import tempfile
import threading
import time
import re
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.contract import BrowserContext, NetworkState, PageSnapshot


@dataclass
class ChromeSnapshot:
    url: str
    page_snapshot: PageSnapshot
    browser_context: BrowserContext
    network_state: NetworkState
    target_id: str = ""
    websocket_url: str = ""


def launch_chrome(url: str, port: int = 9222, user_data_dir: str = "", proxy_url: str = "") -> None:
    chrome = _find_chrome()
    if not chrome:
        raise RuntimeError("Google Chrome executable was not found")

    profile_dir = user_data_dir or str(Path(tempfile.gettempdir()) / f"codex-human-verification-chrome-{port}")
    proxy_server, proxy_extension = _prepare_chrome_proxy(proxy_url, profile_dir)
    args = [
        chrome,
        f"--remote-debugging-port={port}",
        f"--user-data-dir={profile_dir}",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-features=IsolateOrigins,site-per-process",
    ]
    if proxy_server:
        args.append(f"--proxy-server={proxy_server}")
    if proxy_extension:
        args.append(f"--load-extension={proxy_extension}")
    args.append(url)
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    _wait_for_debugger(f"http://127.0.0.1:{port}", timeout=30)


def _turnstile_interceptor_script() -> str:
    return r"""
(() => {
  if (window.__codexTurnstileHookInstalled) return;
  window.__codexTurnstileHookInstalled = true;

  const wrap = (ts) => {
    if (!ts || !ts.render || ts.__codexWrapped) return;
    const originalRender = ts.render.bind(ts);
    ts.render = (container, params = {}) => {
      window.__codexTurnstileParams = {
        sitekey: params.sitekey || '',
        action: params.action || '',
        data: params.cData || '',
        pagedata: params.chlPageData || '',
        userAgent: navigator.userAgent,
        pageUrl: location.href
      };
      window.__codexTurnstileCallback = params.callback;
      return originalRender(container, params);
    };
    ts.__codexWrapped = true;
  };

  let value = window.turnstile;
  try {
    Object.defineProperty(window, 'turnstile', {
      configurable: true,
      get() {
        return value;
      },
      set(next) {
        value = next;
        wrap(value);
      }
    });
  } catch (_) {}

  const timer = setInterval(() => wrap(window.turnstile), 10);
  setTimeout(() => clearInterval(timer), 30000);
})();
"""


def install_turnstile_interceptor(debugging_url: str, target_url: str = "") -> None:
    script = _turnstile_interceptor_script()
    targets = _json_get(f"{debugging_url.rstrip('/')}/json")
    selected = _related_targets(_find_target(debugging_url, target_url, targets=targets), targets)
    installable = [item for item in selected if item.get("type") in ("page", "iframe") and item.get("webSocketDebuggerUrl")]
    if not installable:
        raise RuntimeError("No Chrome page or iframe target is available for script injection")

    for target in installable:
        with CDPSession(target["webSocketDebuggerUrl"]) as cdp:
            cdp.call("Page.enable")
            cdp.call("Page.addScriptToEvaluateOnNewDocument", {"source": script})
            _eval(cdp, script)


def navigate_with_turnstile_interceptor(debugging_url: str, url: str, target_url: str = "", wait_seconds: int = 30) -> None:
    target = _find_target(debugging_url, target_url)
    ws_url = target.get("webSocketDebuggerUrl")
    if not ws_url:
        raise RuntimeError("Selected Chrome target does not expose a websocket debugger URL")

    script = _turnstile_interceptor_script()
    with CDPSession(ws_url) as cdp:
        cdp.call("Page.enable")
        cdp.call("Page.addScriptToEvaluateOnNewDocument", {"source": script})
        _eval(cdp, script)
        cdp.call(
            "Target.setAutoAttach",
            {
                "autoAttach": True,
                "waitForDebuggerOnStart": True,
                "flatten": True,
            },
        )
        cdp.call("Page.navigate", {"url": url})

        deadline = time.time() + wait_seconds
        while time.time() < deadline:
            msg = cdp.read_message(timeout=1)
            if not msg or msg.get("method") != "Target.attachedToTarget":
                continue
            params = msg.get("params") or {}
            session_id = params.get("sessionId")
            info = params.get("targetInfo") or {}
            if not session_id:
                continue
            if info.get("type") in ("page", "iframe"):
                try:
                    cdp.call("Page.enable", session_id=session_id)
                    cdp.call("Page.addScriptToEvaluateOnNewDocument", {"source": script}, session_id=session_id)
                    try:
                        cdp.call(
                            "Runtime.evaluate",
                            {"expression": script, "awaitPromise": True, "returnByValue": True},
                            session_id=session_id,
                        )
                    except RuntimeError as exc:
                        if "Cannot find default execution context" not in str(exc):
                            raise
                finally:
                    cdp.call("Runtime.runIfWaitingForDebugger", session_id=session_id)


def navigate(debugging_url: str, url: str, target_url: str = "") -> None:
    target = _find_target(debugging_url, target_url)
    ws_url = target.get("webSocketDebuggerUrl")
    if not ws_url:
        raise RuntimeError("Selected Chrome target does not expose a websocket debugger URL")
    with CDPSession(ws_url) as cdp:
        cdp.call("Page.enable")
        cdp.call("Page.navigate", {"url": url})


def wait_for_turnstile_params(debugging_url: str, target_url: str = "", wait_seconds: int = 20) -> Dict[str, Any]:
    deadline = time.time() + wait_seconds
    params: Dict[str, Any] = {}
    while time.time() < deadline:
        try:
            install_turnstile_interceptor(debugging_url, target_url)
        except Exception:
            pass
        params = get_turnstile_params(debugging_url, target_url)
        if params.get("sitekey") and (params.get("pagedata") or params.get("data") or params.get("action")):
            return params
        time.sleep(0.5)
    return params


def get_turnstile_params(debugging_url: str, target_url: str = "") -> Dict[str, Any]:
    expression = """
(() => {
  const params = window.__codexTurnstileParams || {};
  return {
    sitekey: params.sitekey || '',
    action: params.action || '',
    data: params.data || '',
    pagedata: params.pagedata || '',
    userAgent: params.userAgent || navigator.userAgent,
    pageUrl: params.pageUrl || location.href,
    hasCallback: typeof window.__codexTurnstileCallback === 'function'
  };
})()
"""
    targets = _json_get(f"{debugging_url.rstrip('/')}/json")
    selected = _related_targets(_find_target(debugging_url, target_url, targets=targets), targets)
    best: Dict[str, Any] = {}
    for target in selected:
        ws_url = target.get("webSocketDebuggerUrl")
        if target.get("type") not in ("page", "iframe") or not ws_url:
            continue
        with CDPSession(ws_url) as cdp:
            params = _eval(cdp, expression) or {}
        if params.get("sitekey"):
            return params
        if params:
            best = params
    return best


def collect_snapshot(debugging_url: str, target_url: str = "", wait_seconds: int = 15) -> ChromeSnapshot:
    deadline = time.time() + wait_seconds
    last_snapshot: Optional[ChromeSnapshot] = None
    while True:
        targets = _json_get(f"{debugging_url.rstrip('/')}/json")
        target = _find_target(debugging_url, target_url, targets=targets)
        snapshot = _collect_snapshot_once(debugging_url, target_url, target, targets)
        last_snapshot = snapshot
        has_challenge_detail = bool(snapshot.page_snapshot.iframe_srcs or snapshot.page_snapshot.hidden_fields)
        looks_blocked = _looks_blocked(
            snapshot.page_snapshot.text,
            list(snapshot.page_snapshot.iframe_srcs or []),
            list(snapshot.page_snapshot.hidden_fields or []),
        )
        if has_challenge_detail or (snapshot.page_snapshot.text and not looks_blocked) or time.time() >= deadline:
            return snapshot
        time.sleep(0.5)


def _collect_snapshot_once(debugging_url: str, target_url: str, target: Dict[str, Any], targets: List[Dict[str, Any]]) -> ChromeSnapshot:
    ws_url = target.get("webSocketDebuggerUrl")
    if not ws_url:
        raise RuntimeError("Selected Chrome target does not expose a websocket debugger URL")

    related_targets = _related_targets(target, targets)
    target_text = " ".join(
        [str(item.get("title") or "") for item in related_targets]
        + [str(item.get("url") or "") for item in related_targets]
    )
    target_iframes = [
        str(item.get("url") or "")
        for item in related_targets
        if item.get("type") == "iframe" and item.get("url")
    ]

    with CDPSession(ws_url) as cdp:
        actual_url = _eval(cdp, "location.href") or target.get("url") or target_url
        title = _eval(cdp, "document.title") or ""
        text = _eval(cdp, "document.body ? document.body.innerText : ''") or ""
        html = _eval(cdp, "document.documentElement ? document.documentElement.outerHTML : ''") or ""
        iframes = _eval(
            cdp,
            "Array.from(document.querySelectorAll('iframe')).map((x) => x.src || x.getAttribute('src') || '')",
        ) or []
        hidden = _eval(
            cdp,
            "Array.from(document.querySelectorAll('input[type=hidden], textarea[name]')).map((x) => x.name || x.id || '')",
        ) or []
        cookies_raw = _eval(cdp, "document.cookie") or ""

    merged_iframes = _dedupe([*iframes, *target_iframes])
    cookies = _parse_cookie_header(cookies_raw)
    snapshot_text = f"{target_text} {title} {text}"
    if _looks_chrome_error(actual_url, snapshot_text, html):
        status = 599
    elif _looks_blocked(snapshot_text, merged_iframes, hidden):
        status = 403
    else:
        status = 200
    return ChromeSnapshot(
        url=actual_url,
        page_snapshot=PageSnapshot(
            html=html,
            text=f"{target_text}\n{title}\n{text}".strip(),
            iframe_srcs=merged_iframes,
            hidden_fields=hidden,
        ),
        browser_context=BrowserContext(cookies=cookies),
        network_state=NetworkState(status_code=status),
        target_id=target.get("id", ""),
        websocket_url=ws_url,
    )


def inject_turnstile_token(debugging_url: str, token: str, target_url: str = "") -> Dict[str, Any]:
    target = _find_target(debugging_url, target_url)
    ws_url = target.get("webSocketDebuggerUrl")
    if not ws_url:
        raise RuntimeError("Selected Chrome target does not expose a websocket debugger URL")

    expression = f"""
(() => {{
  const token = {json.dumps(token)};
  let field = document.querySelector('[name="cf-turnstile-response"]');
  if (!field) {{
    field = document.createElement('textarea');
    field.name = 'cf-turnstile-response';
    field.style.display = 'none';
    const form = document.querySelector('form') || document.body || document.documentElement;
    form.appendChild(field);
  }}
  field.value = token;
  field.dispatchEvent(new Event('input', {{ bubbles: true }}));
  field.dispatchEvent(new Event('change', {{ bubbles: true }}));

  let callbackCalled = false;
  if (typeof window.__codexTurnstileCallback === 'function') {{
    window.__codexTurnstileCallback(token);
    callbackCalled = true;
  }}

  const widget = document.querySelector('.cf-turnstile, [data-sitekey]');
  if (widget) {{
    widget.setAttribute('data-codex-token-injected', 'true');
  }}

  const submit = document.querySelector('button[type="submit"], input[type="submit"]');
  if (submit && !submit.disabled) {{
    submit.click();
  }}

  return {{
    injected: true,
    hasField: Boolean(field),
    hasWidget: Boolean(widget),
    callbackCalled,
    clickedSubmit: Boolean(submit && !submit.disabled)
  }};
}})()
"""
    with CDPSession(ws_url) as cdp:
        result = _eval(cdp, expression)
    return result or {"injected": False}


def inject_captcha_token(debugging_url: str, token: str, method: str, target_url: str = "") -> Dict[str, Any]:
    target = _find_target(debugging_url, target_url)
    ws_url = target.get("webSocketDebuggerUrl")
    if not ws_url:
        raise RuntimeError("Selected Chrome target does not expose a websocket debugger URL")

    response_names = {
        "turnstile": ["cf-turnstile-response", "g-recaptcha-response"],
        "recaptcha_v2": ["g-recaptcha-response"],
        "recaptcha_v3": ["g-recaptcha-response"],
        "hcaptcha": ["h-captcha-response", "g-recaptcha-response"],
        "funcaptcha": ["fc-token"],
    }.get(method, ["g-recaptcha-response", "cf-turnstile-response", "h-captcha-response"])

    expression = f"""
(() => {{
  const token = {json.dumps(token)};
  const names = {json.dumps(response_names)};
  const method = {json.dumps(method)};
  const fields = [];
  for (const name of names) {{
    let field = document.querySelector(`[name="${{name}}"]`);
    if (!field) {{
      field = document.createElement('textarea');
      field.name = name;
      field.style.display = 'none';
      const form = document.querySelector('form') || document.body || document.documentElement;
      form.appendChild(field);
    }}
    field.value = token;
    field.dispatchEvent(new Event('input', {{ bubbles: true }}));
    field.dispatchEvent(new Event('change', {{ bubbles: true }}));
    fields.push(name);
  }}

  let callbackCalled = false;
  const callbackNames = [
    '__codexTurnstileCallback',
    'tsCallback',
    'onSubmit',
    'onCaptchaSolved',
    'onCaptchaSuccess'
  ];
  for (const name of callbackNames) {{
    if (typeof window[name] === 'function') {{
      try {{
        window[name](token);
        callbackCalled = true;
      }} catch (_) {{}}
    }}
  }}
  if (method === 'turnstile' && typeof window.__codexTurnstileCallback === 'function') {{
    window.__codexTurnstileCallback(token);
    callbackCalled = true;
  }}

  const widget = document.querySelector('.cf-turnstile, .g-recaptcha, .h-captcha, [data-sitekey]');
  if (widget) {{
    widget.setAttribute('data-codex-token-injected', 'true');
  }}

  const submit = document.querySelector('button[type="submit"], input[type="submit"]');
  if (submit && !submit.disabled) {{
    submit.click();
  }}

  return {{
    injected: fields.length > 0,
    method,
    fields,
    hasWidget: Boolean(widget),
    callbackCalled,
    clickedSubmit: Boolean(submit && !submit.disabled)
  }};
}})()
"""
    with CDPSession(ws_url) as cdp:
        result = _eval(cdp, expression)
    return result or {"injected": False, "method": method}


def extract_turnstile_sitekey(debugging_url: str, target_url: str = "") -> str:
    targets = _json_get(f"{debugging_url.rstrip('/')}/json")
    for target in targets:
        url = target.get("url") or ""
        match = re.search(r"/(0x[A-Za-z0-9_-]{10,})/", url)
        if "challenges.cloudflare.com" in url and match:
            return match.group(1)

    target = _find_target(debugging_url, target_url, targets=targets)
    ws_url = target.get("webSocketDebuggerUrl")
    if not ws_url:
        return ""
    expression = """
(() => {
  const node = document.querySelector('[data-sitekey], .cf-turnstile');
  return node ? (node.getAttribute('data-sitekey') || '') : '';
})()
"""
    with CDPSession(ws_url) as cdp:
        return _eval(cdp, expression) or ""


class CDPSession:
    def __init__(self, websocket_url: str):
        parsed = urllib.parse.urlparse(websocket_url)
        self.host = parsed.hostname or "127.0.0.1"
        self.port = parsed.port or 80
        self.path = parsed.path
        self.sock: Optional[socket.socket] = None
        self.next_id = 0

    def __enter__(self) -> "CDPSession":
        self.sock = socket.create_connection((self.host, self.port), timeout=10)
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        request = (
            f"GET {self.path} HTTP/1.1\r\n"
            f"Host: {self.host}:{self.port}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            "Sec-WebSocket-Version: 13\r\n\r\n"
        )
        self.sock.sendall(request.encode("ascii"))
        response = self.sock.recv(4096)
        if b" 101 " not in response:
            raise RuntimeError("Chrome websocket upgrade failed")
        return self

    def __exit__(self, *_args: Any) -> None:
        if self.sock:
            self.sock.close()

    def call(self, method: str, params: Dict[str, Any] | None = None, session_id: str = "") -> Dict[str, Any]:
        self.next_id += 1
        msg_id = self.next_id
        message = {"id": msg_id, "method": method, "params": params or {}}
        if session_id:
            message["sessionId"] = session_id
        payload = json.dumps(message).encode("utf-8")
        self._send_frame(payload)
        while True:
            data = self.read_message()
            if not data:
                continue
            if data.get("id") == msg_id:
                if "error" in data:
                    raise RuntimeError(json.dumps(data["error"], ensure_ascii=False))
                return data.get("result") or {}

    def read_message(self, timeout: float | None = None) -> Dict[str, Any]:
        if not self.sock:
            raise RuntimeError("CDP socket is not connected")
        original_timeout = self.sock.gettimeout()
        if timeout is not None:
            self.sock.settimeout(timeout)
        try:
            frame = self._recv_frame()
        except socket.timeout:
            return {}
        finally:
            if timeout is not None:
                self.sock.settimeout(original_timeout)
        if not frame:
            return {}
        return json.loads(frame.decode("utf-8", errors="ignore"))

    def _send_frame(self, payload: bytes) -> None:
        if not self.sock:
            raise RuntimeError("CDP socket is not connected")
        header = bytearray([0x81])
        length = len(payload)
        if length < 126:
            header.append(0x80 | length)
        elif length < 65536:
            header.extend([0x80 | 126])
            header.extend(struct.pack("!H", length))
        else:
            header.extend([0x80 | 127])
            header.extend(struct.pack("!Q", length))
        mask = os.urandom(4)
        header.extend(mask)
        masked = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        self.sock.sendall(bytes(header) + masked)

    def _recv_frame(self) -> bytes:
        if not self.sock:
            raise RuntimeError("CDP socket is not connected")
        first = self.sock.recv(2)
        if len(first) < 2:
            return b""
        opcode = first[0] & 0x0F
        length = first[1] & 0x7F
        if length == 126:
            length = struct.unpack("!H", _recv_exact(self.sock, 2))[0]
        elif length == 127:
            length = struct.unpack("!Q", _recv_exact(self.sock, 8))[0]
        if first[1] & 0x80:
            mask = _recv_exact(self.sock, 4)
            payload = _recv_exact(self.sock, length)
            payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        else:
            payload = _recv_exact(self.sock, length)
        if opcode == 8:
            return b""
        return payload


def _eval(cdp: CDPSession, expression: str) -> Any:
    result = cdp.call(
        "Runtime.evaluate",
        {
            "expression": expression,
            "awaitPromise": True,
            "returnByValue": True,
        },
    )
    remote = result.get("result") or {}
    return remote.get("value")


def _recv_exact(sock: socket.socket, length: int) -> bytes:
    chunks = []
    remaining = length
    while remaining > 0:
        chunk = sock.recv(remaining)
        if not chunk:
            raise RuntimeError("Chrome websocket closed unexpectedly")
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def _find_target(debugging_url: str, target_url: str = "", targets: List[Dict[str, Any]] | None = None) -> Dict[str, Any]:
    targets = targets if targets is not None else _json_get(f"{debugging_url.rstrip('/')}/json")
    pages = [t for t in targets if t.get("type") == "page"]
    if target_url:
        for target in pages:
            if target_url in (target.get("url") or ""):
                return target
    if pages:
        return pages[0]
    raise RuntimeError("No debuggable Chrome page target was found")


def _related_targets(target: Dict[str, Any], targets: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    target_id = target.get("id")
    related = [target]
    related.extend(item for item in targets if item.get("parentId") == target_id)
    return related


def _dedupe(values: List[str]) -> List[str]:
    seen = set()
    out = []
    for value in values:
        if not value or value in seen:
            continue
        seen.add(value)
        out.append(value)
    return out


def _json_get(url: str) -> Any:
    with urllib.request.urlopen(url, timeout=10) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _wait_for_debugger(debugging_url: str, timeout: int) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            _json_get(f"{debugging_url.rstrip('/')}/json/version")
            return
        except (urllib.error.URLError, TimeoutError, ConnectionError):
            time.sleep(0.25)
    raise RuntimeError("Chrome remote debugging endpoint did not become ready")


def _find_chrome() -> str:
    env_candidates = [
        os.environ.get("CHROME_PATH", ""),
        os.environ.get("CHROME_BIN", ""),
        os.environ.get("GOOGLE_CHROME_SHIM", ""),
    ]
    candidates = [
        *env_candidates,
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        str(Path.home() / "Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
        "/Applications/Google Chrome Canary.app/Contents/MacOS/Google Chrome Canary",
        "/Applications/Chromium.app/Contents/MacOS/Chromium",
        os.path.join(os.environ.get("ProgramFiles", ""), "Google", "Chrome", "Application", "chrome.exe"),
        os.path.join(os.environ.get("ProgramFiles(x86)", ""), "Google", "Chrome", "Application", "chrome.exe"),
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "Google", "Chrome", "Application", "chrome.exe"),
    ]
    for candidate in candidates:
        if candidate and os.path.exists(candidate):
            return candidate
    for name in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "chrome"):
        found = shutil.which(name)
        if found:
            return found
    return ""


def _prepare_chrome_proxy(proxy_url: str, profile_dir: str) -> tuple[str, str]:
    if not proxy_url:
        return "", ""

    parsed = urllib.parse.urlparse(proxy_url)
    if not parsed.scheme or not parsed.hostname:
        return proxy_url, ""

    if parsed.scheme in ("socks5", "socks4") and parsed.username:
        local_proxy = _start_authenticated_socks_bridge(proxy_url)
        return local_proxy, ""

    port = f":{parsed.port}" if parsed.port else ""
    proxy_server = f"{parsed.scheme}://{parsed.hostname}{port}"
    if not parsed.username:
        return proxy_server, ""

    extension_dir = Path(profile_dir) / "proxy_auth_extension"
    extension_dir.mkdir(parents=True, exist_ok=True)
    manifest = {
        "manifest_version": 3,
        "name": "Codex Proxy Auth",
        "version": "1.0.0",
        "permissions": ["webRequest", "webRequestAuthProvider"],
        "host_permissions": ["<all_urls>"],
        "background": {"service_worker": "background.js"},
    }
    username = urllib.parse.unquote(parsed.username or "")
    password = urllib.parse.unquote(parsed.password or "")
    background = f"""
chrome.webRequest.onAuthRequired.addListener(
  function(details, callback) {{
    callback({{
      authCredentials: {{
        username: {json.dumps(username)},
        password: {json.dumps(password)}
      }}
    }});
  }},
  {{ urls: ["<all_urls>"] }},
  ["asyncBlocking"]
);
"""
    (extension_dir / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    (extension_dir / "background.js").write_text(background, encoding="utf-8")
    return proxy_server, str(extension_dir)


_PROXY_BRIDGES: Dict[str, tuple[socketserver.ThreadingTCPServer, int]] = {}


class _ThreadingTCPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def handle_error(self, request: socket.socket, client_address: tuple[str, int]) -> None:
        return


def _start_authenticated_socks_bridge(proxy_url: str) -> str:
    existing = _PROXY_BRIDGES.get(proxy_url)
    if existing:
        return f"http://127.0.0.1:{existing[1]}"

    upstream = urllib.parse.urlparse(proxy_url)
    if upstream.scheme != "socks5":
        raise RuntimeError(f"Chrome bridge only supports authenticated socks5 proxies, got {upstream.scheme}")

    class Handler(socketserver.BaseRequestHandler):
        def handle(self) -> None:
            _handle_http_proxy_client(self.request, upstream)

    server = _ThreadingTCPServer(("127.0.0.1", 0), Handler)
    port = int(server.server_address[1])
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    _PROXY_BRIDGES[proxy_url] = (server, port)
    return f"http://127.0.0.1:{port}"


def _handle_http_proxy_client(client: socket.socket, upstream: urllib.parse.ParseResult) -> None:
    client.settimeout(30)
    first = _read_until(client, b"\r\n\r\n", limit=65536)
    if not first:
        return
    header = first.decode("iso-8859-1", errors="replace")
    line = header.split("\r\n", 1)[0]
    parts = line.split()
    if len(parts) < 2:
        return

    method = parts[0].upper()
    if method == "CONNECT":
        host, port_s = parts[1].rsplit(":", 1)
        remote = _socks5_connect(upstream, host, int(port_s))
        client.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
        _relay_bidirectional(client, remote)
        return

    parsed = urllib.parse.urlparse(parts[1])
    host = parsed.hostname
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    if not host:
        return
    path = urllib.parse.urlunparse(("", "", parsed.path or "/", parsed.params, parsed.query, parsed.fragment))
    rewritten = header.replace(parts[1], path, 1)
    remote = _socks5_connect(upstream, host, port)
    remote.sendall(rewritten.encode("iso-8859-1", errors="replace"))
    _relay_bidirectional(client, remote)


def _read_until(sock: socket.socket, marker: bytes, limit: int) -> bytes:
    data = b""
    while marker not in data and len(data) < limit:
        chunk = sock.recv(4096)
        if not chunk:
            break
        data += chunk
    return data


def _socks5_connect(upstream: urllib.parse.ParseResult, host: str, port: int) -> socket.socket:
    sock = socket.create_connection((upstream.hostname or "", upstream.port or 1080), timeout=30)
    username = urllib.parse.unquote(upstream.username or "").encode("utf-8")
    password = urllib.parse.unquote(upstream.password or "").encode("utf-8")
    sock.sendall(b"\x05\x01\x02")
    response = _recv_exact(sock, 2)
    if response != b"\x05\x02":
        raise RuntimeError("SOCKS5 proxy did not accept username/password authentication")
    sock.sendall(b"\x01" + bytes([len(username)]) + username + bytes([len(password)]) + password)
    auth = _recv_exact(sock, 2)
    if auth != b"\x01\x00":
        raise RuntimeError("SOCKS5 proxy authentication failed")
    host_b = host.encode("idna")
    request = b"\x05\x01\x00\x03" + bytes([len(host_b)]) + host_b + struct.pack("!H", port)
    sock.sendall(request)
    reply = _recv_exact(sock, 4)
    if len(reply) < 4 or reply[1] != 0:
        raise RuntimeError(f"SOCKS5 connect failed with code {reply[1] if len(reply) > 1 else 'unknown'}")
    atyp = reply[3]
    if atyp == 1:
        _recv_exact(sock, 4)
    elif atyp == 3:
        length = _recv_exact(sock, 1)[0]
        _recv_exact(sock, length)
    elif atyp == 4:
        _recv_exact(sock, 16)
    _recv_exact(sock, 2)
    return sock


def _relay_bidirectional(left: socket.socket, right: socket.socket) -> None:
    try:
        left.setblocking(False)
        right.setblocking(False)
        sockets = [left, right]
        while True:
            readable, _, errored = select.select(sockets, [], sockets, 60)
            if errored or not readable:
                break
            for source in readable:
                try:
                    data = source.recv(65536)
                except OSError:
                    return
                if not data:
                    return
                target = right if source is left else left
                try:
                    target.sendall(data)
                except OSError:
                    return
    finally:
        try:
            left.close()
        finally:
            right.close()


def _parse_cookie_header(cookie_header: str) -> Dict[str, str]:
    cookies: Dict[str, str] = {}
    for part in cookie_header.split(";"):
        if "=" not in part:
            continue
        name, value = part.split("=", 1)
        cookies[name.strip()] = value.strip()
    return cookies


def _looks_blocked(text: str, iframes: List[str], hidden: List[str]) -> bool:
    blob = " ".join([text, *iframes, *hidden]).lower()
    markers = (
        "cloudflare",
        "verify you are human",
        "please verify",
        "security check",
        "just a moment",
        "请验证您是真人",
        "进行安全验证",
        "请稍候",
        "challenges.cloudflare.com",
        "cf-turnstile-response",
    )
    return any(marker in blob for marker in markers)


def _looks_chrome_error(url: str, text: str, html: str) -> bool:
    blob = f"{url} {text} {html[:2000]}".lower()
    markers = (
        "chrome-error://chromewebdata",
        "err_timed_out",
        "err_no_supported_proxies",
        "err_proxy_connection_failed",
        "err_tunnel_connection_failed",
        "err_connection_timed_out",
        "无法访问此网站",
        "响应时间过长",
        "proxy server",
    )
    return any(marker in blob for marker in markers)
