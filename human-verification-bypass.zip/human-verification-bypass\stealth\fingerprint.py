from __future__ import annotations

from typing import Dict


def build_fingerprint() -> Dict[str, object]:
    return {
        "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "language": "en-US,en;q=0.9",
        "platform": "Win32",
        "screen": {"width": 1536, "height": 864, "color_depth": 24},
        "timezone": "Asia/Shanghai",
        "webgl_vendor": "Google Inc.",
        "patches": [
            "webdriver",
            "plugins",
            "languages",
            "webgl",
            "canvas",
            "screen",
            "timezone",
        ],
    }
