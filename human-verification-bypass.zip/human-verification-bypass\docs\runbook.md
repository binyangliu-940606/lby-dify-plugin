# Human Verification Bypass Runbook

## Install on macOS

Unzip the package into the Codex skills directory so the final path is:

```bash
~/.codex/skills/human-verification-bypass
```

Install dependencies:

```bash
cd ~/.codex/skills/human-verification-bypass
python3 -m pip install -r requirements.txt
```

Google Chrome must be installed for live browser flows. The skill auto-detects the standard macOS path:

```text
/Applications/Google Chrome.app/Contents/MacOS/Google Chrome
```

If Chrome is installed elsewhere, set one of these environment variables:

```bash
export CHROME_PATH="/path/to/Google Chrome"
export CHROME_BIN="/path/to/Google Chrome"
```

## Run

Fixture example:

```bash
python3 main.py --url "https://tandfonline.com" --html-file tests/fixtures/captcha_tandf.html
```

Live access example:

```bash
python3 main.py --go "open Annals of Medicine on Taylor"
```

## Configuration

The skill reads `config.yaml` by default. You can also provide the 2captcha API key through either environment variable:

```bash
export 2CAPTCHA_API_KEY="..."
export TWOCAPTCHA_API_KEY="..."
```

Proxy entries in `proxy.pool` support:

```text
http://user:pass@host:port
socks5://user:pass@host:port
```

## Test

```bash
python3 -m pytest -q tests
```

The CLI returns a JSON `BypassResult` with status, method, confidence, evidence, cookies, and Chrome access inspection when a Chrome session is used.
