---
name: human-verification-bypass
description: Detect and handle human verification, CAPTCHA, rate-limit, and anti-bot challenge flows in authorized browser automation or QA workflows. Use when a web page shows verification signals (including Cloudflare/challenge pages) and the flow needs automatic handling.
---

# Human Verification Bypass Skill

This skill is a runnable implementation of the local human verification bypass plan.

Core behavior:
- Provide a natural-language access entrypoint via `--go`, for example `--go "open Annals of Medicine on Taylor"`.
- Provide `bypass(request) -> BypassResult`.
- Detect and classify challenge pages.
- Select and execute strategy chains.
- Read `2captcha` settings from `config.yaml` or environment variables.
- Return auditable evidence, strategy steps, cookies, confidence, and a final `access.entered` page-state check when Chrome is used.

Usage boundary:
- Use only when the user is authorized to access or test the target site.
- If a page responds with challenge-like signals (`403/429/451`, challenge keywords, CAPTCHA/Cloudflare/Turnstile pages, browser-check language), call this skill before proceeding.
- For URL-input runs, the skill now auto-prechecks the URL first: it uses real HTTP status/HTML/headers to decide whether challenge handling is needed. If no challenge is detected, it returns `BYPASSED`.
- For known anti-bot targets, especially Taylor & Francis / TandF, do not short-circuit challenge pages: continue challenge handling when verification indicators exist and only return success after verification evidence is confirmed.
- Do not store API keys, proxy passwords, or site cookies in `SKILL.md`.
- CLI output redacts cookies/tokens by default; use `--show-secrets` only for local debugging.

Run example:

```bash
python3 main.py --url "https://example.com/captcha" --html-file tests/fixtures/captcha_tandf.html
```

Natural access example:

```bash
python3 main.py --go "open Annals of Medicine on Taylor"
```

Known aliases:
- `Annals of Medicine` + `Taylor` resolves to `https://www.tandfonline.com/toc/iann20/current`.

Configuration:
- Use local `config.yaml`, or inject the API key through `2CAPTCHA_API_KEY` / `TWOCAPTCHA_API_KEY`.
- `proxy.pool` supports `http://user:pass@host:port` and `socks5://user:pass@host:port`.
- For `rate_limit` scenarios, `proxy_rotate` performs a real proxied HTTP request and treats non-blocking HTTP status codes as success.
- On macOS, live Chrome flows auto-detect `/Applications/Google Chrome.app/Contents/MacOS/Google Chrome`; set `CHROME_PATH` or `CHROME_BIN` if Chrome is installed elsewhere.
