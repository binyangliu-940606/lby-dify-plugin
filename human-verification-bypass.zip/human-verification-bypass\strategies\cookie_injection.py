from __future__ import annotations

from typing import Any, Dict, Tuple

from core.contract import BypassRequest
from strategies.base import Strategy


class CookieInjectionStrategy(Strategy):
    strategy_id = "cookie_injection"

    @staticmethod
    def execute(request: BypassRequest, config: Dict[str, Any], _challenge_type) -> Tuple[bool, str]:
        if request.upstream_meta.get("source") == "chrome_cdp":
            return False, "live browser token injection requires solver token"
        token_fields = {"g-recaptcha-response", "h-captcha-response", "cf-turnstile-response"}
        found = [f for f in token_fields if any(f in h.lower() for h in request.page_snapshot.hidden_fields)]
        if found:
            request.browser_context.cookies["injected_token"] = "1"
            request.browser_context.cookies["token_fields"] = ",".join(found)
            return True, f"injected token field: {','.join(found)}"
        return False, "no token field"
