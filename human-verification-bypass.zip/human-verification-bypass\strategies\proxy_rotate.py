from __future__ import annotations

from typing import Any, Dict, Tuple
from urllib.parse import urlsplit, urlunsplit

import httpx

from core.contract import BypassRequest
from strategies.base import Strategy


BLOCK_STATUSES = {403, 429, 451}


def _mask_proxy(proxy_url: str) -> str:
    parts = urlsplit(proxy_url)
    if not parts.username:
        return proxy_url
    host = parts.hostname or ""
    port = f":{parts.port}" if parts.port else ""
    masked_netloc = f"{parts.username}:***@{host}{port}"
    return urlunsplit((parts.scheme, masked_netloc, parts.path, parts.query, parts.fragment))


def _response_cookies(response: httpx.Response) -> Dict[str, str]:
    return {name: value for name, value in response.cookies.items()}


class ProxyRotateStrategy(Strategy):
    strategy_id = "proxy_rotate"

    @staticmethod
    def execute(request: BypassRequest, config: Dict[str, Any], _challenge_type) -> Tuple[bool, str]:
        proxy_cfg = config.get("proxy") or {}
        pool = proxy_cfg.get("pool") or []
        if not pool:
            request.browser_context.headers["x-proxy"] = "disabled"
            return False, "proxy pool empty"

        max_attempts = int(proxy_cfg.get("max_attempts") or min(len(pool), 3))
        timeout = float(proxy_cfg.get("timeout") or 30)
        block_statuses = set(proxy_cfg.get("block_statuses") or BLOCK_STATUSES)
        request.browser_context.cookies.pop("js_challenge", None)

        last_note = "proxy not attempted"
        start_idx = request.attempt_count % len(pool)
        for offset in range(max_attempts):
            idx = (start_idx + offset) % len(pool)
            proxy_url = str(pool[idx]).strip()
            masked_proxy = _mask_proxy(proxy_url)
            request.browser_context.headers["x-proxy"] = masked_proxy
            request.browser_context.headers["x-proxy-attempt"] = str(request.attempt_count + 1)
            request.attempt_count += 1

            try:
                with httpx.Client(
                    proxy=proxy_url,
                    timeout=timeout,
                    follow_redirects=True,
                    headers={
                        "User-Agent": request.browser_context.headers.get(
                            "user-agent",
                            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                        ),
                        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                        "Accept-Language": "en-US,en;q=0.9",
                    },
                ) as client:
                    response = client.get(request.url)
            except Exception as exc:
                last_note = f"proxy failed via {masked_proxy}: {type(exc).__name__}"
                continue

            status_code = response.status_code
            request.network_state.status_code = status_code
            request.network_state.response_headers = dict(response.headers)

            if status_code not in block_statuses:
                request.browser_context.cookies.update(_response_cookies(response))
                request.browser_context.cookies["proxy_verified"] = str(status_code)
                return True, f"proxy verified via {masked_proxy}: status={status_code}"

            last_note = f"proxy still blocked via {masked_proxy}: status={status_code}"

        return False, last_note
