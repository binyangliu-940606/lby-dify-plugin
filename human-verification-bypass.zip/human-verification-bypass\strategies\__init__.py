from .base import Strategy
from .js_auto_execute import JSChallengeStrategy
from .cookie_injection import CookieInjectionStrategy
from .external_solver import ExternalSolver2CaptchaStrategy
from .proxy_rotate import ProxyRotateStrategy
from .session_rotate import SessionRotateStrategy
from .wait_human import WaitHumanStrategy

STRATEGY_MAP = {
    "js_auto_execute": JSChallengeStrategy,
    "cookie_injection": CookieInjectionStrategy,
    "external_solver_2captcha": ExternalSolver2CaptchaStrategy,
    "proxy_rotate": ProxyRotateStrategy,
    "session_rotate": SessionRotateStrategy,
    "wait_human": WaitHumanStrategy,
}

